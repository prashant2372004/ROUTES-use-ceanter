import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { createNote, initialNotes } from '../../Config/Config';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const New = React.lazy(() => import("./New"))

const AddNotes = () => {

  const [show, setShow] = useState(false);
  const [notes, setNotes] = useState(initialNotes);
  const navigate = useNavigate()

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleChange = (e) => {
    setNotes({ ...notes, [e.target.name] : e.target.value })
  }

  const handleAddNote = async () => {
    if(notes?.title && notes?.description){
      const response = await createNote(notes)
      if(response?.isAdd){
        toast.success("Note Added")
        navigate("/notes")
      } else{
        toast.error("Error Found")
        console.log(response?.status);
      }
    } else {
      toast.error("Please Enter Valid Details")
    }
    handleClose()
    console.log(notes);
  }
  
  return (
    <div className='container'>
      <div className="py-5 row">
        <div className="col-12">
          <button className='px-5 py-2 btn btn-secondary' onClick={handleShow}>Add Note</button>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <h1 className='text-[48px] text-[red] font-bold'>Add New Note</h1>
            </Modal.Header>
            <Modal.Body>
              <form action="#" >
                <div className="mb-3 form-floating">
                  <input type="text" className="form-control" id="floatingInput" placeholder="Enter Your Title" name='title' value={notes?.title} onChange={handleChange} />
                  <label htmlFor="floatingInput">Username</label>
                </div>
                <div className="mb-3 form-floating">
                  <input type="text" className="form-control" id="floatingPassword" placeholder="Description" name='description' value={notes?.description} onChange={handleChange} />
                  <label htmlFor="floatingPassword">Password</label>
                </div>
                <div className="text-center form-Button">
                </div>
              </form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button variant="primary" onClick={handleAddNote}>
                Add Notes
              </Button>
            </Modal.Footer>
          </Modal>
               <New/>
        </div>
      </div>
    </div>
  )
}

export default AddNotes
