import React, { useState } from 'react'
import { checkUser, initialUser } from '../../Config/Config'
import { toast } from 'react-toastify'
import { useNavigate } from 'react-router-dom'

const Login = () => {

  const [ user, setUser ] = useState(initialUser)
  const navigate = useNavigate()

  const handleChange = (e) => {
    setUser({ ...user, [ e.target.name ]:e.target.value })
  }

  const handleLogin = (e) => {
    e.preventDefault()
    if(user?.username && user?.password){
      const response = checkUser(user)
      if(response?.isValidUser){
        toast.success("Login Successfull")
        navigate("/add-notes")
      } else{
        toast.error("Invalid User")
      }
    } else{
      toast.error("Please Enter Valid Details")
    }

  }

  return (
    <div className='container '>
      <div className="row">
        <div className="col-12 d-flex justify-content-center align-items-center" style={{height:"100vh"}}>
          <form action="#" className='w-50'>
            <div className="form-floating mb-3">
              <input type="text" className="form-control" id="floatingInput" placeholder="Enter Your Username" name='username' value={user?.username} onChange={handleChange}/>
              <label htmlFor="floatingInput">Username</label>
            </div>
            <div className="form-floating mb-3">
              <input type="password" className="form-control" id="floatingPassword" placeholder="Password" name='password' value={user?.password} onChange={handleChange}/>
              <label htmlFor="floatingPassword">Password</label>
            </div>
            <div className="form-Button text-center">
              <button className="btn btn-primary px-5 py-2" onClick={handleLogin}>Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login
