import React, { Suspense } from 'react'
import "./App.css"
import { Route, Routes } from 'react-router-dom'
const Login = React.lazy(() => import("./Components/View/Login/Login"))
const AddNotes = React.lazy(() => import("./Components/View/AddNotes/AddNotes"))
const Notes = React.lazy(() => import("./Components/View/Notes/Notes"))
const SingleNote = React.lazy(() => import("./Components/View/SingleNotes/SingleNotes"))
const Loader = React.lazy(() => import("./Components/Global/Loader/Loader"))
const New = React.lazy(() => import("./Components/View/AddNotes/New"))

const App = () => {
  return (
    <div className='container-fluid'>
      <div className="row">
        <div className="border col-2" style={{ height: "100vh" }}>
          Sidebar
        </div>
        <div className="col-10">
          
        <Suspense fallback={<Loader />}>
            
            <Routes>
              <Route path='/' element={<Login />} />
              <Route path='/add-notes' element={<AddNotes />} />
              
              <Route path='/New' element={<New/>} />
              <Route path='/notes' element={<Notes />} />
              <Route path='/notes/:id' element={<SingleNote />} />
            </Routes>
          </Suspense>
        </div>
      </div>
    </div>
  )
}

export default App;